#' Single Layer Perceptron
#'
#' Single Layer Perceptron function
#'
#' This function takes four parameters and iterates over the input instances for user given epochs. It learns the class from the training instances by calculating differences in weight and by updating/adjusting accordingly. It returns the classification errors for further adjustments.
#' @param df is the training dataframe
#' @param lb contains the training labels
#' @param lr is the learning rate
#' @param ep is the epochs

simple_perceptron <- function(df, lb, lr, ep) {

  w <- rep(0, dim(df)[2] + 1)
  err <- rep(0, ep)
  for (i in 1:ep) {
    for (j in 1:length(y)) {
      b <- sum(w[2:length(w)] *
                 as.numeric(df[j, ])) + w[1]
      if(b < 0) {
        pred <- -1
      } else {
        pred <- 1
      }
      wdiff <- lr * (lb[j] - pred) *
        c(1, as.numeric(df[j, ]))
      w <- w + wdiff

      # calculate error
      if ((lb[j] - pred) != 0.0) {
        err[i] <- err[i] + 1
      }

    }
  }
  print(w)
  return(err)
}
